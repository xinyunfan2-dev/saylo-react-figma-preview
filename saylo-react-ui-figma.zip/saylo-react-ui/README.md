# Saylo React UI 方向预览

根据 `docs/boards/看板二-Codex评审讨论.html` 的讨论制作的独立静态原型。页面：Home、Hermes「我的写法」、Profile。实现黄紫辅助色、柔和光晕、玻璃卡片和底部 Liquid 风格导航，支持浅色与深色。

```bash
npm ci
npm run dev
```

打开终端显示的本地地址。`npm run build` 可生成静态文件到 `dist/`。

交互仅用于观察布局和流程：风格及语言选择、主题、预设草稿、A/B 选项、保存与启用在浏览器本地演示；无账号、录音、购买或云端改写。Hermes 的 10/25/45 秒帮助提示仅改变引导文案，不自动选择答案。页面中的用量、历史和试写结果是示例数据。

截图：`previews/home-light.png`、`previews/agent-light.png`、`previews/profile-dark.png`。

Figma Make 导入步骤与范围说明见 [FIGMA-START-HERE.md](FIGMA-START-HERE.md)。
